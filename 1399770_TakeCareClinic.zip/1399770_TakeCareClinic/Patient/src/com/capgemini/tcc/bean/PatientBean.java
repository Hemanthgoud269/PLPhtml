package com.capgemini.tcc.bean;
 
import java.sql.Date;
 
public class PatientBean {
 
 
	//PARAMETERS FOR THE CLASS
	private int pid;
	private String pname;
	private int age;
	private int pno;
	private String pdesc;
	private Date pdate;
 
	//GETTER AND SETTER METHODS FOR THE ABOVE PARAMETERS
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public Date getPdate() {
		return pdate;
	}
	public void setPdate(Date pdate) {
		this.pdate = pdate;
	}
 
 
 
 
}